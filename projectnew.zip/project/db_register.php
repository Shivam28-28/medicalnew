<?php
// Database configuration
$host = 'localhost'; // or your database host
$db = 'admin_db'; // your database name
$user = 'root'; // your database username
$pass = ''; // your database password

try {
    // Create a new PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = trim($_POST['username']);
        // $email = trim($_POST['email']);
        $password = trim($_POST['password']);

        // Validate input
        if (empty($username) ||  empty($password)) {
            die("Please fill in all fields.");
        }

        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Prepare an SQL statement
        $stmt = $pdo->prepare("INSERT INTO users (username,  password) VALUES (:username, :password)");

        // Bind parameters
        $stmt->bindParam(':username', $username);
        // $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $hashed_password);

        // Execute the statement
        if ($stmt->execute()) {
            echo "User  registered successfully.";
            // header("Location : admin.php");
        } else {
            echo "Error: Could not register user.";
        }
    }
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
}
?>

