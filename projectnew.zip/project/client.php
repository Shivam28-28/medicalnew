<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Management</title>
</head>
<body>

<h1>Client</h1>
<form action="db.php" method="POST">
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" required><br><br>

    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required><br><br>

    <label for="phone">Phone Number:</label>
    <input type="tel" id="phone" name="phone" required><br><br>

    <label for="address">Address:</label>
    <textarea id="address" name="address" required></textarea><br><br>

    <input type="submit" value="Add Customer">
</form>

<h1>Search Client</h1>
<form action="" method="POST">
    <label for="searchName">Enter Client Name:</label>
    <input type="text" id="searchName" name="searchName" required><br><br>

    <input type="submit" value="Search">
</form>

<?php
// Database connection
$servername = "localhost"; // Your server name
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "client"; // Your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the search form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['searchName'])) {
    // Get the search name from the form
    $searchName = $_POST['searchName'];

    // Prepare and bind
    $stmt = $conn->prepare("SELECT * FROM customers WHERE name LIKE ?");
    $searchTerm = "%" . $searchName . "%"; // Use LIKE for partial matches
    $stmt->bind_param("s", $searchTerm);

    // Execute the statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    // Check if any clients found
    if ($result->num_rows > 0) {
        // Output data of each row
        echo "<h2>Search Results:</h2>";
        while ($row = $result->fetch_assoc()) {
            echo "Name: " . htmlspecialchars($row["name"]) . " - Email: " . htmlspecialchars($row["email"]) . " - Phone: " . htmlspecialchars($row["phone"]) . " - Address: " . htmlspecialchars($row["address"]) . "<br>";
        }
    } else {
        echo "No clients found with that name.";
    }

    // Close the statement
    $stmt->close();
}

// Close connection
$conn->close();
?>

</body>
</html>