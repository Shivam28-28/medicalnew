<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['loggedin'])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shivam Pathocare Lab</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Your Brand</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto"> <!-- Right-aligned navbar items -->
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle active" href="#" id="reportDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Report
            </a>
            <div class="dropdown-menu" aria-labelledby="reportDropdown">
                <a class="dropdown-item" href="blood.php">Blood</a>
                <a class="dropdown-item" href="sugar.php">Sugar</a>
                <a class="dropdown-item" href="bp.php">BP</a>
                <a class="dropdown-item" href="stomach.php">Stomach</a>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="client.php">Client</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Your page content goes here -->
<h1 style="text-align: center;">Shivam Pathocare Lab</h1>

<p>Welcome to Shivam Pathocare Lab. We are dedicated to providing precise, comprehensive, and timely clinical reports to support accurate diagnoses and effective treatments. Our state-of-the-art facility and experienced team uphold the highest standards in pathology services.</p>

<h2>Why Choose Us?</h2>
<ul>
    <li><strong>Precision & Quality:</strong> We follow stringent protocols to ensure accuracy and reliability in every report.</li>
    <li><strong>Experienced Team:</strong> Our skilled professionals bring expertise and commitment to each analysis, supporting healthcare providers in delivering optimal patient care.</li>
    <li><strong>Advanced Technology:</strong> Equipped with modern diagnostic tools, we provide results that patients and healthcare providers can rely on.</li>
</ul>
<p>Our commitment to excellence in clinical pathology makes us a trusted partner in your healthcare journey.</p>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>