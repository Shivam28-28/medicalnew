<?php
include 'header.php';
?>

<h1>Sugar Report</h1>