<?php
include 'header.php';
?>

<h1>Stomach Report</h1>