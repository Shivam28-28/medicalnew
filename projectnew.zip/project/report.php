<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Form</title>
</head>
<body>

<h2>User Information Form</h2>
<form method="POST" action="">
    <label for="name">Name:</label><br>
    <input type="text" id="name" name="name" required><br><br>

    <label for="age">Age:</label><br>
    <input type="number" id="age" name="age" required><br><br>

    <label for="gender">Gender:</label><br>
    <select id="gender" name="gender" required>
        <option value="male">male</option>
        <option value="female">Female</option>
        <option value="other">Other</option>
    </select><br><br>

    <label for="type">Type:</label><br>
    <select id="type" name="type" required>
        <option value="blood">Blood</option>
        <option value="sugar">Sugar</option>
        <option value="b.p">B.P</option>
    </select><br><br>

    <label for="whatsapp">WhatsApp Number:</label><br>
    <input type="text" id="whatsapp" name="whatsapp" required><br><br>

    <input type="submit" value="Submit">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize input data
    $name = htmlspecialchars($_POST['name']);
    $age = htmlspecialchars($_POST['age']);
    $gender = htmlspecialchars($_POST['gender']);
    $whatsapp = htmlspecialchars($_POST['whatsapp']);

    // Include TCPDF library


    // Create new PDF document
    

    // Set document information
    


    // Set default header data
    
    // Set header and footer fonts
    

    // Set default monospaced font
    

    // Set margins
    

    // Set auto page breaks
    

    // Add a page
    

    // Set font
    

    // Create HTML content
    // $html = "<h1>User Information</h1>
    //          <p><strong>Name:</strong> $name</p>
    //          <p><strong>Age:</strong> $age</p>
    //          <p><strong>Gender:</strong> $gender</p>
    //          <p><strong>WhatsApp Number:</strong> $whatsapp</p>";

    // Output the HTML content
    // $pdf->writeHTML($html, true, false, true, false, '');

    // Close and output PDF document
    // $pdf->Output('user_information.pdf', 'D'); // 'D' for download

    // exit; // Stop further execution
}
?>

</body>
</html>