<?php
// Database credentials
$servername = "localhost"; // Change this to your server name
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "admin_db"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start session to manage user state
// session_start();

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture form data and sanitize input
    $admin_username = $conn->real_escape_string($_POST['username']);
    $admin_password = $_POST['password']; // Do not escape the password

    // Prepare and execute the query to fetch the admin credentials
    $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
    $stmt->bind_param("s", $admin_username);
    $stmt->execute();
    $stmt->store_result();

    // Check if the username exists
    if ($stmt->num_rows > 0) {
        // Bind result
        $stmt->bind_result($hashed_password);
        $stmt->fetch();

        // Verify the password (assuming passwords are stored hashed)
           // Verify the password (assuming passwords are stored hashed)
    if (password_verify($admin_password, $hashed_password)) {
        // Set session variable to indicate the user is logged in
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $admin_username; // Optionally store username

        // Redirect to index.php
        header("Location: index.php");
        exit(); // Make sure to call exit after redirecting
    } else {
        // Incorrect password
        echo "<script>alert('Valid username or password');</script>";
    }
} else {
    // Username does not exist
    echo "<script>alert('Invalid username or password');</script>";
}

    // Close the statement
    $stmt->close();
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
</head>
<body>
    <form action="admin_login.php" method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>
        <br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        <br>
        <input type="submit" value="Login">
    </form>
</body>
</html>