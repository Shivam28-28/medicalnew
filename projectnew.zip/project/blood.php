<?php
include 'header.php';
?>

<h1>Blood Report</h1>